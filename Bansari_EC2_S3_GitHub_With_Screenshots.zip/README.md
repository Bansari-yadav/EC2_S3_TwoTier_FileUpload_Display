# Two-Tier File Upload & Display with EC2, S3, and IAM Roles

**Student:** Bansari Yadav  
**NetID:** byadav1  
**Course:** Cloud Computing

## Overview

This lab uses two independent EC2 instances with Node.js/Express applications, communicating indirectly through a single Amazon S3 object (`shared.txt`). The Uploader accepts `.txt` files up to 1 MB, storing accepted content in S3. The Viewer retrieves and displays the current object. The EC2 instances receive application code embedded in their launch-template user-data and use IAM instance profiles rather than hard-coded AWS credentials.

## Repository layout

- `lab03/uploader-app/` — uploader `app.js` and `package.json`
- `lab03/viewer-app/` — viewer `app.js` and `package.json`
- `create_app_stack.sh` — script to provision the lab resources
- `delete_app_stack.sh` — cleanup script
- `.env.example` — safe configuration template; copy locally to `.env` and fill in your own values
- `screenshots/` — genuine screenshots supplied for this lab (SS6 not provided)

## Evidence checklist

| No. | Required evidence | File |
|---|---|---|
| 1 | Local uploader/viewer folders and four app files | [Screenshot](screenshots/SS1_Folder_Structure.png) |
| 2 | Successful text upload | [Screenshot](screenshots/SS2_Upload_Success.png) |
| 3 | Rejection of .txt file over 1 MB | [Screenshot](screenshots/SS3_File_Too_Large.png) |
| 4 | Rejection of non-.txt file | [Screenshot](screenshots/SS4_Invalid_File.png) |
| 5 | Viewer showing first file | [Screenshot](screenshots/SS5_Viewer.png) |
| 6 | Viewer showing refreshed second file | **Not available — screenshot not provided** |
| 7 | Both launch templates | [Screenshot](screenshots/SS7_Launch_Templates.png) |
| 8 | Multiple uploader template versions | [Screenshot](screenshots/SS8_Template_Versions.png) |
| 9 | Uploader IAM policy | [Screenshot](screenshots/SS9A_Uploader_IAM.png) |
| 10 | Viewer IAM policy | [Screenshot](screenshots/SS9B_Viewer_IAM.png) |
| 11 | Create script result with both EC2 public IPs | [Screenshot](screenshots/SS10_EC2_Deployment.png) |
| 12 | Delete script completion output | [Screenshot](screenshots/SS11_Cleanup.png) |

**Evidence status:** 11 genuine screenshot images have been included. SS6 (Viewer showing refreshed second file) is missing; no other screenshot has been relabeled to stand in for it. Do not redeploy solely to reproduce this image.

## Why separate IAM roles?

The Uploader and Viewer have different responsibilities, so using separate IAM roles follows the principle of least privilege. The Uploader is permitted to perform `s3:PutObject` only on `shared.txt`, whereas the Viewer is permitted to perform `s3:GetObject` on `shared.txt` and `s3:ListBucket` on its bucket. Keeping these permissions separate reduces unnecessary access and limits what each application can do if it is compromised.

## Why embed code in EC2 user-data?

Embedding the local application code directly in EC2 user-data allows each instance to reconstruct the code at startup without fetching it from Git or S3. Thus the instance does not need Git or S3 code-download credentials, although it still needs IAM permissions to access the shared S3 data object.

## Deployment and cleanup

The `create_app_stack.sh` script constructs the S3 bucket, scoped IAM roles and profiles, launch templates, and EC2 instances. The `delete_app_stack.sh` script attempts to terminate the recorded instances and remove the corresponding AWS resources. During this lab, four EC2 instances were terminated and the remaining services were checked for cleanup. The laboratory security group was also deleted separately.

**Safety:** Do not commit `.env`, credentials, or SSH private keys. These scripts were preserved as supplied; review for any cleanup edge cases before ever reusing them. Do not redeploy just to capture missing screenshots.
